import socket


c_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c_sock.connect(("0.0.0.0", 12345))

    # Input message from the user
message = input("Enter a message to send to the server: ")

    # Send the message to the server
c_sock.send(message.encode('utf-8'))

    # Receive the response from the server
response = c_sock.recv(1024).decode('utf-8')
print(f"Server response: {response}")

c_sock.close()

