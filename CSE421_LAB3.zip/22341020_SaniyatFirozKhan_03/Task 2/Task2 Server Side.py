import socket

s_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s_sock.bind(("0.0.0.0", 12345))
s_sock.listen(5)

print("Hello from 12345. Waiting for connections...")
while True:
        conn, addr = s_sock.accept()
        print(f"Connection established with {addr},waiting for message...")

        # Receive message from client
        data = conn.recv(1024).decode('utf-8')
        print(f"Received message: {data}.Thank you.")

        vowel_count=0
        for i in data:
            if i in "aeiouAEIOU":
                vowel_count+=1
                if vowel_count > 0:
                    if vowel_count <= 2:
                        response = "Enough vowels"
                    else:
                        response = "Too many vowels"
                    
            else:
                response = "Not enough vowels"
                
        conn.send(response.encode('utf-8'))
        conn.close()