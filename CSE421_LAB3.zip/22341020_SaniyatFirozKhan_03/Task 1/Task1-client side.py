import socket
import socket as s

host_ip = "127.0.0.1"
host_port = 12345
buffer = 1024
format = "utf-8"

client_ip = s.gethostbyname(s.gethostname())
device_name = s.gethostname()

c_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c_sock.connect((host_ip, host_port))

client_info = f"IP: {client_ip}, Host Device Name: {device_name}.Hello from the other side."
c_sock.send(client_info.encode(format))

print(c_sock.recv(buffer).decode(format))

c_sock.close()
