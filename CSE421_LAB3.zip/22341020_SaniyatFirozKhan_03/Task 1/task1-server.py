import socket

host_ip = "127.0.0.1"
host_port = 12345
buffer = 1024
format = "utf-8"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((host_ip, host_port))
server_socket.listen(5)
print(f"Hello.Server is listening for connections on {host_ip}:{host_port}...")

while True:
    client_socket, client_address = server_socket.accept()
    print(f"Connected to client at {client_address[0]}.")

    client_info = client_socket.recv(buffer).decode(format)
    if client_info:  
        print(f"Client Information: {client_info}")
    else:
        print("No client information received.")
    
    client_socket.send("Received your information.Goodbye :) ".encode(format))
    client_socket.close()
