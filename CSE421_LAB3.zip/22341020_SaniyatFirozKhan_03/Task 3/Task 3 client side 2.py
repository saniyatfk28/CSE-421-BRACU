import socket

host_ip = "127.0.0.1" 
host_port = 12345

c_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

c_sock.connect((host_ip, host_port))

while True:
    input = input("Enter a Message: ")

    if input in ["END", "end", "End"]:
        # Prepare the disconnect message
        message = "DISCONNECT".encode("utf-8")
        length = str(len(message)).encode("utf-8")
        length += b" " * (1024 - len(length))  
        
        c_sock.send(length)
        c_sock.send(message)

        response = c_sock.recv(2048).decode("utf-8")
        print(f"Server response: {response}")
        break
    else:
        message = input.encode("utf-8")
        length = str(len(message)).encode("utf-8")
        length += b" " * (1024 - len(length))  
        
        c_sock.send(length)
        c_sock.send(message)

        response = c_sock.recv(2048).decode("utf-8")
        print(f"Server response: {response}")

c_sock.close()
print("Disconnected from the server.")
