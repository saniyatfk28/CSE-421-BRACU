import socket


buffer = 1024  

s_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

s_sock.bind(("0.0.0.0", 12345))

s_sock.listen(5)
print(f"Server started. Listening for connections on {"0.0.0.0"}:{12345}...")

# Handle multiple clients
while True:
    c_sock, c_address =  s_sock.accept()
    print(f"Connected to {c_address}")

    connected = True
    while connected:
        message_length =  c_sock.recv(buffer).decode("utf-8") 
        
        if message_length:
            message_length = int(message_length)
            msg =  c_sock.recv(message_length).decode("utf-8")

            vowel_count = 0
            for i in msg:
                if i in "aeiouAEIOU":
                    vowel_count += 1

            if vowel_count == 0:
                response = "Not enough vowels"
            elif vowel_count <= 2:
                response = "Enough vowels"
            else:
                response = "Too many vowels"
            
            c_sock.send(response.encode("utf-8"))

            if msg == "DISCONNECT":
                print(f"Terminating connection with {c_address}")
                connected = False

    c_sock.close()
