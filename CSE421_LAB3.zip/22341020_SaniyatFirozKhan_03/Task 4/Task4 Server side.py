import socket


s_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s_sock.bind(("0.0.0.0", 12345))

s_sock.listen(5)
print(f"looking for connections on {"0.0.0.0"}:{"12345"}...")

while True:

    c_sock, _ = s_sock.accept()
    print("Connected to client successfully!")

    hours = int(c_sock.recv(1024).decode("utf-8"))

    if hours <= 40:
        salary = hours * 200
    else:
        salary = 8000 + (hours - 40) * 300

    c_sock.send(f"Your salary is Tk {salary}".encode("utf-8"))

    c_sock.close()
