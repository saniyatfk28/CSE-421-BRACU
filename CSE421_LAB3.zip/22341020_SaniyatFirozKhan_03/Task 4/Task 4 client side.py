import socket


server_ip = "127.0.0.1"  
server_port = 12345
buffer = 1024  
format = "utf-8"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client_socket.connect((server_ip, server_port))

client_socket.send(input("Enter hours worked: ").encode("utf-8"))

print(client_socket.recv(buffer).decode("utf-8"))

client_socket.close()
